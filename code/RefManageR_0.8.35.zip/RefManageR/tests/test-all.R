library(testthat)
test_check("RefManageR")