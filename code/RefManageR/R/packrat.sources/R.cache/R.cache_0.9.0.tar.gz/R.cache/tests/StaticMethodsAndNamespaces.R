R.cache::clearCache(dirs=sample(1:10))
