# Added '...' to some base functions. These will later be
# turned into default functions by setMethodS3().



############################################################################
# HISTORY:
# 2005-12-06
# o Created to please R CMD check.
############################################################################
