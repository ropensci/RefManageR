library(testthat)
library(plyr)

test_package("plyr")
